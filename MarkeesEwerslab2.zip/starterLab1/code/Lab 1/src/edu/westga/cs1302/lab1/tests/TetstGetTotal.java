package edu.westga.cs1302.lab1.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.lab1.model.Bill;
import edu.westga.cs1302.lab1.model.BillItem;

class TetstGetTotal {
	
	@Test
	public void testGetTotaSingle() {
		Bill bill = new Bill();
		BillItem milk = new BillItem("Milk", 5.00);
	
		bill.addItem(milk);
	
		double expectedTotal = 6.5;

		assertEquals(expectedTotal, bill.getTotal(), 0.01);
	}

	@Test
	public void testGetTotalWithMultiple() {
		Bill bill = new Bill();
		BillItem milk = new BillItem("Milk", 5.00);
		BillItem eggs = new BillItem("Eggs", 3.00);

		bill.addItem(milk);
		bill.addItem(eggs);

		double expectedTotal = 10.4;

		assertEquals(expectedTotal, bill.getTotal(), 0.01);
	}
	
	@Test
	public void testNoBillItems() {
		Bill bill = new Bill();
	
		double expectedTotal = 0;

		assertEquals(expectedTotal, bill.getTotal(), 0);
	}
	
}
