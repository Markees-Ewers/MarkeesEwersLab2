package edu.westga.cs1302.lab1.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.lab1.model.Bill;
import edu.westga.cs1302.lab1.model.BillItem;

class TestBill {

	@Test
	void testBill() {
		BillItem milk = new BillItem("milk", 5.00);

		Bill bill = new Bill();

		bill.addItem(milk);

		assertEquals(bill.getItems().size(), 1);

	}

	@Test
	void testMulitpleItems() {
		BillItem milk = new BillItem("milk", 5.00);
		BillItem eggs = new BillItem("eggs", 3.00);

		Bill bill = new Bill();

		bill.addItem(eggs);
		bill.addItem(milk);

		assertEquals(bill.getItems().size(), 2);
	}

	@Test
	void testBillItemNotNull() {

		BillItem eggs = new BillItem("eggs", 3.00);

		Bill bill = new Bill();

		bill.addItem(eggs);

		bill.addItem(eggs);

		assertThrows(IllegalArgumentException.class, () -> {
			bill.addItem(null);
		});
	}
	
}
