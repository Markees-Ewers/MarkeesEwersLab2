package edu.westga.cs1302.lab1.view;

import java.util.ArrayList;
import edu.westga.cs1302.lab1.model.Bill;
import edu.westga.cs1302.lab1.model.BillItem;

/**
 * The Class BillView.
 * 
 * @author me00070
 * @version fall 2024
 * 
 */
public class BillView {
	
	/** The Constant ROUND_AMOUNT. */
	public static final double ROUND_AMOUNT = 100.00;

	/**
	 * Return a String containing the list of bill items and total for the bill.
	 *
	 * @param bill of all items
	 * @return a String containing the list of bill items and total for the bill
	 * @precondition none
	 * @postcondition none
	 */
	public String createReciept(Bill bill) {
		String text = "ITEMS" + System.lineSeparator();
		double subTotal = Bill.STARTING_SUBTOTAL;
		ArrayList<BillItem> items = bill.getItems();
		for (BillItem item : items) {
			text += item.getName() + " - " + item.getAmount() + System.lineSeparator();
			subTotal += item.getAmount();
		}

		text += System.lineSeparator();
		text += "SUBTOTAL - $" + subTotal + System.lineSeparator();
		double tax = subTotal * Bill.TAX;
		double tip = subTotal * Bill.TIP;
		text += "TAX - $" + tax + System.lineSeparator();
		text += "TIP - $" + tip + System.lineSeparator();
		double total = (subTotal + tip + tax);
		text += "TOTAL - $" + Math.round(total * ROUND_AMOUNT) / ROUND_AMOUNT;
		System.out.println(text);

		return text;
	}
	
}
