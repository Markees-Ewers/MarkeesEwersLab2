package edu.westga.cs1302.lab1.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.lab1.model.Bill;
import edu.westga.cs1302.lab1.model.BillItem;

class TestGetSubtotal {

		@Test
		public void testGetSubTotal() {
			Bill bill = new Bill();
			BillItem milk = new BillItem("Milk", 5.00);
			
			bill.addItem(milk);
			
			double subtotal = 5;
			double expectedTotal = subtotal;

			assertEquals(expectedTotal, bill.getSubtotal(), 0.01);
		}
		
		@Test
		public void testGetSubtotalMultiple() {
			Bill bill = new Bill();
			BillItem milk = new BillItem("Milk", 5.00);
			BillItem eggs = new BillItem("Eggs", 3.00);
			BillItem cookies = new BillItem("cookies", 5);

			bill.addItem(milk);
			bill.addItem(eggs);
			bill.addItem(cookies);

			double subtotal = 13.00;
			double expectedTotal = subtotal;
			
			assertEquals(expectedTotal, bill.getSubtotal(), 0.01);
			
		}
		
		@Test
		public void testGetSubtotalWithNoItems() {
			Bill bill = new Bill();

			double subtotal = 0;
			double expectedTotal = subtotal;
			
			assertEquals(expectedTotal, bill.getSubtotal(), 0.01);
			
		}

}
